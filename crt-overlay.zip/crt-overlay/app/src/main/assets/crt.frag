#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform vec2 uRes;
uniform float uTime;
uniform float uMode;       // 0..6 тип ЭЛТ
uniform float uIntensity;  // общая сила строк/маски
uniform float uScan;
uniform float uMask;
uniform float uSize;       // размер "пикселя" в px
uniform float uVig;
uniform float uCorner;
uniform float uNoise;
uniform float uFlicker;
uniform float uRoll;

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

vec3 phosphor(float idx) {
    if (idx < 0.5) return vec3(1.0, 0.0, 0.0);
    if (idx < 1.5) return vec3(0.0, 1.0, 0.0);
    return vec3(0.0, 0.0, 1.0);
}

void main() {
    // координаты сверху вниз, в пикселях
    vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);
    vec2 uv = p / uRes;
    float sz = max(uSize, 1.0);
    float pitch = 3.0 * sz;

    float scanD = 0.0;   // тёмные строки развёртки
    float maskD = 0.0;   // затемнение маски
    float gridD = 0.0;   // сетка LCD
    vec3 tint = vec3(0.0);

    // ---- строки развёртки ----
    float beam = 0.5 - 0.5 * cos(6.2831853 * p.y / pitch); // 0 в центре луча, 1 в промежутке
    float expo = 1.3;
    if (uMode > 2.5 && uMode < 3.5) expo = 0.8;  // arcade: толстые линии
    if (uMode > 3.5 && uMode < 4.5) expo = 1.6;  // VHS
    scanD = pow(clamp(beam, 0.0, 1.0), expo);

    // ---- маска ----
    if (uMode < 0.5) {
        // 0: апертурная решётка (Trinitron)
        vec3 c = phosphor(mod(floor(p.x / sz), 3.0));
        maskD = 0.45;
        tint = c * 0.30;
    } else if (uMode < 1.5) {
        // 1: теневая маска (круглые точки)
        float rowH = 2.0 * sz;
        float row = floor(p.y / rowH);
        float x = p.x / sz + 1.5 * mod(row, 2.0);
        vec3 c = phosphor(mod(floor(x), 3.0));
        vec2 q = vec2(fract(x) - 0.5, fract(p.y / rowH) - 0.5);
        float dotv = 1.0 - smoothstep(0.30, 0.60, length(q));
        maskD = (1.0 - dotv) * 0.75;
        tint = c * dotv * 0.35;
    } else if (uMode < 2.5) {
        // 2: щелевая маска (телевизор)
        vec3 c = phosphor(mod(floor(p.x / sz), 3.0));
        float colTriad = floor(p.x / pitch);
        float yy = p.y / (4.0 * sz) + 0.5 * mod(colTriad, 2.0);
        float slot = smoothstep(0.78, 0.90, fract(yy));
        maskD = 0.4 + 0.4 * slot;
        tint = c * 0.3 * (1.0 - slot);
    } else if (uMode < 3.5) {
        // 3: аркадный монитор
        vec3 c = phosphor(mod(floor(p.x / sz), 3.0));
        maskD = 0.2;
        tint = c * 0.15;
    } else if (uMode < 4.5) {
        // 4: VHS / композит
        vec3 c = phosphor(mod(floor(p.x / sz), 3.0));
        maskD = 0.2;
        tint = c * 0.12 + vec3(0.04, 0.0, 0.06) * mod(floor(p.y / sz), 2.0);
    } else if (uMode < 5.5) {
        // 5: пиксельная сетка LCD (scan = горизонтальные, mask = вертикальные линии)
        float w = max(1.0, sz * 0.5);
        float lx = step(pitch - w, mod(p.x, pitch));
        float ly = step(pitch - w, mod(p.y, pitch));
        gridD = max(lx * uMask, ly * uScan) * 0.85;
        scanD = 0.0;
        maskD = 0.0;
        tint = vec3(0.0);
    } else {
        // 6: стекло (виньетка + блик, mask = сила блика)
        scanD = 0.0;
        maskD = 0.0;
        float glare = exp(-pow(length((uv - vec2(0.25, 0.15)) * vec2(1.0, 1.7)) * 3.0, 2.0));
        tint = vec3(glare * 0.10);
    }

    float dark = 1.0 - (1.0 - scanD * uScan) * (1.0 - maskD * uMask);
    dark = 1.0 - (1.0 - dark) * (1.0 - gridD);
    vec3 col = tint * uMask;

    float t = mod(uTime, 3600.0);

    // ---- шум ----
    if (uNoise > 0.001) {
        float nz = hash(floor(p / max(1.0, sz * 0.5)) + floor(t * 24.0) * 17.0);
        dark = 1.0 - (1.0 - dark) * (1.0 - nz * 0.55 * uNoise);
    }

    // ---- бегущая полоса ----
    if (uRoll > 0.001) {
        float rp = fract(t * 0.12);
        float bd = abs(uv.y - rp);
        bd = min(bd, 1.0 - bd);
        float band = 1.0 - smoothstep(0.0, 0.12, bd);
        dark = 1.0 - (1.0 - dark) * (1.0 - band * 0.30 * uRoll);
        col += vec3(band * 0.06 * uRoll);
    }

    // ---- мерцание ----
    if (uFlicker > 0.001) {
        float f = 0.5 * sin(t * 47.0) + 0.5 * sin(t * 13.0 + 1.0);
        dark = clamp(dark * (1.0 + uFlicker * 0.35 * f), 0.0, 1.0);
    }

    dark *= uIntensity;
    col *= uIntensity;

    // ---- виньетка ----
    vec2 d = uv - 0.5;
    float vig = uVig * smoothstep(0.10, 1.0, dot(d, d) * 2.0);
    dark = 1.0 - (1.0 - dark) * (1.0 - vig * 0.9);

    // premultiplied alpha: out = rgb + dst * (1 - a)
    float a = clamp(dark + max(col.r, max(col.g, col.b)), 0.0, 1.0);
    vec3 rgb = min(col, vec3(a));

    // ---- скруглённые углы "стекла" ----
    float r = uCorner * 0.15 * min(uRes.x, uRes.y);
    if (r > 0.5) {
        vec2 q = abs(p - 0.5 * uRes) - (0.5 * uRes - vec2(r));
        float sdf = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
        float cm = clamp(sdf / 1.5 + 0.5, 0.0, 1.0);
        rgb *= (1.0 - cm);
        a = max(a, cm);
    }

    gl_FragColor = vec4(rgb, a);
}
