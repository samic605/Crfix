package com.crtoverlay

import android.accessibilityservice.AccessibilityService
import android.view.WindowManager.LayoutParams
import android.view.accessibility.AccessibilityEvent

/**
 * Режим «без блокировки касаний». Окно службы спецвозможностей Android считает доверенным,
 * поэтому касания проходят сквозь фильтр при любой прозрачности. Служба ничего не читает
 * с экрана и не отслеживает действия — она нужна только как хозяин окна.
 */
class CrtAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: CrtAccessibilityService? = null
    }

    private var controller: OverlayController? = null

    val isOn: Boolean get() = controller?.isShowing == true

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        controller = OverlayController(this, LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
    }

    fun setOn(on: Boolean) {
        val c = controller ?: return
        if (on) c.show() else c.hide()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        controller?.hide()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        controller?.hide()
        instance = null
        super.onDestroy()
    }
}
