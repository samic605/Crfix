package com.crtoverlay

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLSurfaceView

/** Прозрачный GL-вид: рисует только эффект ЭЛТ, остальное пропускает как есть. */
class CrtGlView(context: Context) : GLSurfaceView(context) {

    val crtRenderer = CrtRenderer(context)

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setZOrderOnTop(true)
        setRenderer(crtRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }
}
