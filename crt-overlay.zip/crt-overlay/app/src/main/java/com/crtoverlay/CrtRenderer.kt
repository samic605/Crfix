package com.crtoverlay

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.SystemClock
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CrtRenderer(private val ctx: Context) : GLSurfaceView.Renderer {

    @Volatile
    var settings: CrtSettings = CrtSettings.forPreset(0)

    private var program = 0
    private var width = 1
    private var height = 1
    private val t0 = SystemClock.elapsedRealtime()
    private val locations = HashMap<String, Int>()

    private val quad: FloatBuffer =
        ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
            it.position(0)
        }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glDisable(GLES20.GL_DITHER)
        locations.clear()
        program = buildProgram()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = w
        height = h
        GLES20.glViewport(0, 0, w, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (program == 0) return
        val s = settings

        GLES20.glUseProgram(program)
        GLES20.glUniform2f(u("uRes"), width.toFloat(), height.toFloat())
        GLES20.glUniform1f(u("uTime"), ((SystemClock.elapsedRealtime() - t0) / 1000f) % 3600f)
        GLES20.glUniform1f(u("uMode"), s.preset.toFloat())
        GLES20.glUniform1f(u("uIntensity"), s.intensity)
        GLES20.glUniform1f(u("uScan"), s.scan)
        GLES20.glUniform1f(u("uMask"), s.mask)
        GLES20.glUniform1f(u("uSize"), s.size)
        GLES20.glUniform1f(u("uVig"), s.vignette)
        GLES20.glUniform1f(u("uCorner"), s.corner)
        GLES20.glUniform1f(u("uNoise"), s.noise)
        GLES20.glUniform1f(u("uFlicker"), s.flicker)
        GLES20.glUniform1f(u("uRoll"), s.roll)

        val a = GLES20.glGetAttribLocation(program, "aPos")
        GLES20.glEnableVertexAttribArray(a)
        GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(a)
    }

    private fun u(name: String): Int =
        locations.getOrPut(name) { GLES20.glGetUniformLocation(program, name) }

    private fun readAsset(name: String): String =
        ctx.assets.open(name).bufferedReader().use { it.readText() }

    private fun buildProgram(): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, readAsset("crt.vert"))
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, readAsset("crt.frag"))
        if (vs == 0 || fs == 0) return 0
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val status = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e(TAG, "Link error: " + GLES20.glGetProgramInfoLog(p))
            GLES20.glDeleteProgram(p)
            return 0
        }
        return p
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val status = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e(TAG, "Shader error: " + GLES20.glGetShaderInfoLog(s))
            GLES20.glDeleteShader(s)
            return 0
        }
        return s
    }

    companion object {
        private const val TAG = "CrtRenderer"
    }
}
