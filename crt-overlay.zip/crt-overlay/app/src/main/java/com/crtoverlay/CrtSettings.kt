package com.crtoverlay

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

class Preset(
    val name: String,
    val intensity: Float,
    val scan: Float,
    val mask: Float,
    val size: Float,
    val vignette: Float,
    val corner: Float,
    val noise: Float,
    val flicker: Float,
    val roll: Float
)

/** Индекс пресета = номер режима (uMode) в шейдере. */
val PRESETS = listOf(
    Preset("Trinitron — апертурная решётка", 0.75f, 0.45f, 0.60f, 2f, 0.35f, 0.25f, 0f, 0f, 0f),
    Preset("Теневая маска — круглые точки", 0.80f, 0.50f, 0.70f, 2f, 0.40f, 0.30f, 0f, 0f, 0f),
    Preset("Щелевая маска — телевизор", 0.80f, 0.40f, 0.65f, 2f, 0.35f, 0.25f, 0f, 0f, 0f),
    Preset("Аркадный монитор — жирные строки", 0.85f, 0.80f, 0.30f, 2f, 0.30f, 0.20f, 0f, 0f, 0f),
    Preset("VHS / композит — шум и полоса", 0.70f, 0.50f, 0.20f, 2f, 0.45f, 0.25f, 0.35f, 0.10f, 0.50f),
    Preset("LCD сетка — GBA / DS", 0.70f, 0.60f, 0.60f, 2f, 0.00f, 0.00f, 0f, 0f, 0f),
    Preset("Стекло — виньетка и блик", 0.50f, 0.00f, 0.50f, 2f, 0.55f, 0.35f, 0f, 0f, 0f)
)

class CrtSettings(
    var preset: Int,
    var intensity: Float,
    var scan: Float,
    var mask: Float,
    var size: Float,
    var vignette: Float,
    var corner: Float,
    var noise: Float,
    var flicker: Float,
    var roll: Float
) {
    fun save(ctx: Context) {
        sp(ctx).edit()
            .putInt("preset", preset)
            .putFloat("intensity", intensity)
            .putFloat("scan", scan)
            .putFloat("mask", mask)
            .putFloat("size", size)
            .putFloat("vignette", vignette)
            .putFloat("corner", corner)
            .putFloat("noise", noise)
            .putFloat("flicker", flicker)
            .putFloat("roll", roll)
            .apply()
    }

    fun copyFrom(o: CrtSettings) {
        preset = o.preset; intensity = o.intensity; scan = o.scan; mask = o.mask
        size = o.size; vignette = o.vignette; corner = o.corner
        noise = o.noise; flicker = o.flicker; roll = o.roll
    }

    fun toJson(): JSONObject = JSONObject()
        .put("preset", preset)
        .put("intensity", intensity.toDouble())
        .put("scan", scan.toDouble())
        .put("mask", mask.toDouble())
        .put("size", size.toDouble())
        .put("vignette", vignette.toDouble())
        .put("corner", corner.toDouble())
        .put("noise", noise.toDouble())
        .put("flicker", flicker.toDouble())
        .put("roll", roll.toDouble())

    companion object {
        fun fromJson(o: JSONObject): CrtSettings {
            val i = o.optInt("preset", 0).coerceIn(0, PRESETS.size - 1)
            val d = PRESETS[i]
            fun f(k: String, def: Float) = o.optDouble(k, def.toDouble()).toFloat()
            return CrtSettings(
                i, f("intensity", d.intensity), f("scan", d.scan), f("mask", d.mask),
                f("size", d.size), f("vignette", d.vignette), f("corner", d.corner),
                f("noise", d.noise), f("flicker", d.flicker), f("roll", d.roll)
            )
        }

        fun sp(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences("crt", Context.MODE_PRIVATE)

        fun forPreset(i: Int): CrtSettings {
            val p = PRESETS[i]
            return CrtSettings(
                i, p.intensity, p.scan, p.mask, p.size,
                p.vignette, p.corner, p.noise, p.flicker, p.roll
            )
        }

        fun load(ctx: Context): CrtSettings {
            val sp = sp(ctx)
            val i = sp.getInt("preset", 0).coerceIn(0, PRESETS.size - 1)
            val d = PRESETS[i]
            return CrtSettings(
                i,
                sp.getFloat("intensity", d.intensity),
                sp.getFloat("scan", d.scan),
                sp.getFloat("mask", d.mask),
                sp.getFloat("size", d.size),
                sp.getFloat("vignette", d.vignette),
                sp.getFloat("corner", d.corner),
                sp.getFloat("noise", d.noise),
                sp.getFloat("flicker", d.flicker),
                sp.getFloat("roll", d.roll)
            )
        }
    }
}
