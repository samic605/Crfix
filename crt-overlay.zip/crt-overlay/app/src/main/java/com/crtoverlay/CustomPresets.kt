package com.crtoverlay

import android.content.Context
import org.json.JSONObject

/** Пользовательские пресеты: имя -> настройки. Хранятся в SharedPreferences как JSON. */
object CustomPresets {
    private const val KEY = "custom_presets"

    private fun raw(ctx: Context): JSONObject = try {
        JSONObject(CrtSettings.sp(ctx).getString(KEY, "{}") ?: "{}")
    } catch (_: Exception) {
        JSONObject()
    }

    fun all(ctx: Context): List<Pair<String, CrtSettings>> {
        val o = raw(ctx)
        val out = ArrayList<Pair<String, CrtSettings>>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val v = o.optJSONObject(k) ?: continue
            out.add(k to CrtSettings.fromJson(v))
        }
        return out.sortedBy { it.first.lowercase() }
    }

    fun put(ctx: Context, name: String, s: CrtSettings) {
        val o = raw(ctx)
        o.put(name, s.toJson())
        CrtSettings.sp(ctx).edit().putString(KEY, o.toString()).apply()
    }

    fun remove(ctx: Context, name: String) {
        val o = raw(ctx)
        o.remove(name)
        CrtSettings.sp(ctx).edit().putString(KEY, o.toString()).apply()
    }
}
