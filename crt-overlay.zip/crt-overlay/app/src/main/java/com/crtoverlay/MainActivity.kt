package com.crtoverlay

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var cfg: CrtSettings
    private val rows = ArrayList<SliderRow>()
    private lateinit var toggleBtn: Button
    private lateinit var permBtn: Button
    private lateinit var group: RadioGroup
    private lateinit var customBox: LinearLayout
    private var suppress = false

    private val pct: (Float) -> String = { "${(it * 100).roundToInt()}%" }
    private val px: (Float) -> String = { "${it.roundToInt()} px" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = CrtSettings.load(this)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(32))
        }

        root.addView(tv("CRT Overlay", 28f, true))
        root.addView(
            tv("ЭЛТ-фильтр поверх любых приложений и игр. Касания проходят сквозь него.", 14f, false)
                .apply { setPadding(0, dp(4), 0, dp(16)) }
        )

        permBtn = Button(this).apply {
            text = "Разрешить показ поверх других приложений"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + this@MainActivity.packageName)
                    )
                )
            }
        }
        root.addView(permBtn)

        toggleBtn = Button(this).apply { setOnClickListener { toggle() } }
        root.addView(toggleBtn)

        root.addView(tv("Тип ЭЛТ", 18f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        group = RadioGroup(this)
        PRESETS.forEachIndexed { i, p ->
            val rb = RadioButton(this)
            rb.id = 100 + i
            rb.text = p.name
            rb.textSize = 15f
            group.addView(rb)
        }
        group.check(100 + cfg.preset)
        group.setOnCheckedChangeListener { _, checkedId ->
            if (suppress) return@setOnCheckedChangeListener
            cfg =CrtSettings.forPreset(checkedId - 100)
            cfg.save(this)
            rows.forEach { it.refresh() }
        }
        root.addView(group)

        root.addView(tv("Настройки", 18f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        addSlider(root, "Сила эффекта (строки / маска)", 0f, 1f, 100, { cfg.intensity }, { cfg.intensity = it }, pct)
        addSlider(root, "Строки развёртки", 0f, 1f, 100, { cfg.scan }, { cfg.scan = it }, pct)
        addSlider(root, "Маска / сетка / блик", 0f, 1f, 100, { cfg.mask }, { cfg.mask = it }, pct)
        addSlider(root, "Размер пикселя", 1f, 8f, 7, { cfg.size }, { cfg.size = it }, px)
        addSlider(root, "Виньетка", 0f, 1f, 100, { cfg.vignette }, { cfg.vignette = it }, pct)
        addSlider(root, "Скругление углов", 0f, 1f, 100, { cfg.corner }, { cfg.corner = it }, pct)
        addSlider(root, "Шум", 0f, 1f, 100, { cfg.noise }, { cfg.noise = it }, pct)
        addSlider(root, "Бегущая полоса", 0f, 1f, 100, { cfg.roll }, { cfg.roll = it }, pct)
        addSlider(root, "Мерцание (осторожно, при светочувствительности — не включать)", 0f, 1f, 100, { cfg.flicker }, { cfg.flicker = it }, pct)

        root.addView(Button(this).apply {
            text = "Сбросить к настройкам пресета"
            setOnClickListener {
                cfg = CrtSettings.forPreset(cfg.preset)
                cfg.save(this@MainActivity)
                rows.forEach { it.refresh() }
            }
        })

        root.addView(tv("Мои пресеты", 18f, true).apply { setPadding(0, dp(24), 0, dp(4)) })
        root.addView(Button(this).apply {
            text = "Сохранить текущие настройки как пресет"
            setOnClickListener { askSaveName() }
        })
        customBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(customBox)
        refreshCustom()

        root.addView(
            tv(
                "Фильтр можно ставить на паузу и выключать прямо из шторки уведомлений. " +
                    "Шум, полоса и мерцание анимируются (~30 кадров/с) и заметнее расходуют батарею.",
                13f, false
            ).apply { setPadding(0, dp(16), 0, 0) }
        )

        return ScrollView(this).apply {
            addView(root)
            setOnApplyWindowInsetsListener { v, insets ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val b = insets.getInsets(WindowInsets.Type.systemBars())
                    v.setPadding(b.left, b.top, b.right, b.bottom)
                } else {
                    @Suppress("DEPRECATION")
                    v.setPadding(
                        insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                        insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                    )
                }
                insets
            }
        }
    }

    private fun askSaveName() {
        val input = EditText(this).apply {
            hint = "Например: Для Minecraft"
            setSingleLine()
        }
        val pad = dp(20)
        val box = FrameLayout(this).apply {
            setPadding(pad, dp(8), pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Название пресета")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show()
                } else {
                    CustomPresets.put(this, name, cfg)
                    refreshCustom()
                    Toast.makeText(this, "Сохранено: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun applyCustom(s: CrtSettings) {
        cfg.copyFrom(s)
        cfg.save(this)
        suppress = true
        group.check(100 + cfg.preset)
        suppress = false
        rows.forEach { it.refresh() }
    }

    private fun refreshCustom() {
        customBox.removeAllViews()
        val all = CustomPresets.all(this)
        if (all.isEmpty()) {
            customBox.addView(tv("Пока нет сохранённых пресетов.", 13f, false))
            return
        }
        for ((name, s) in all) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(Button(this).apply {
                text = name
                setAllCaps(false)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    applyCustom(s)
                    Toast.makeText(this@MainActivity, "Применён: $name", Toast.LENGTH_SHORT).show()
                }
            })
            row.addView(Button(this).apply {
                text = "✕"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Удалить пресет «$name»?")
                        .setPositiveButton("Удалить") { _, _ ->
                            CustomPresets.remove(this@MainActivity, name)
                            refreshCustom()
                        }
                        .setNegativeButton("Отмена", null)
                        .show()
                }
            })
            customBox.addView(row)
        }
    }

    private fun toggle() {
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) {
            stopService(i)
        } else if (Settings.canDrawOverlays(this)) {
            startForegroundService(i)
        } else {
            Toast.makeText(this, "Сначала дайте разрешение", Toast.LENGTH_SHORT).show()
        }
        toggleBtn.postDelayed({ refreshButtons() }, 400)
    }

    private fun refreshButtons() {
        permBtn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        toggleBtn.text = if (OverlayService.running) "Выключить фильтр" else "Включить фильтр"
    }

    private fun addSlider(
        parent: LinearLayout, label: String, lo: Float, hi: Float, n: Int,
        read: () -> Float, write: (Float) -> Unit, fmt: (Float) -> String
    ) {
        val row = SliderRow(label, lo, hi, n, read, write, fmt)
        rows.add(row)
        parent.addView(row.title)
        parent.addView(row.bar)
        row.refresh()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun tv(t: String, size: Float, bold: Boolean): TextView {
        val view = TextView(this)
        view.text = t
        view.textSize = size
        if (bold) view.setTypeface(view.typeface, Typeface.BOLD)
        return view
    }

    private inner class SliderRow(
        val label: String,
        val lo: Float,
        val hi: Float,
        val n: Int,
        val read: () -> Float,
        val write: (Float) -> Unit,
        val fmt: (Float) -> String
    ) {
        val title = TextView(this@MainActivity).apply {
            textSize = 14f
            setPadding(0, dp(10), 0, 0)
        }
        val bar = SeekBar(this@MainActivity).apply { max = n }

        init {
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    write(lo + progress * (hi - lo) / n)
                    title.text = "$label: ${fmt(read())}"
                    cfg.save(this@MainActivity)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        fun refresh() {
            bar.progress = (((read() - lo) / (hi - lo)) * n).roundToInt()
            title.text = "$label: ${fmt(read())}"
        }
    }
}
