package com.crtoverlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams

/** Создаёт окно с GL-фильтром и применяет к нему настройки. Работает с любым типом окна. */
class OverlayController(private val ctx: Context, private val type: Int) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: CrtGlView? = null
    private var paused = false

    val isShowing: Boolean get() = view != null
    val isPaused: Boolean get() = paused

    private val ticker = object : Runnable {
        override fun run() {
            view?.requestRender()
            handler.postDelayed(this, 33)
        }
    }

    // слушатель надо держать сильной ссылкой — SharedPreferences хранит его слабо
    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applySettings() }

    fun show() {
        if (view != null) return
        val v = CrtGlView(ctx)
        val lp = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT,
            type,
            LayoutParams.FLAG_NOT_FOCUSABLE or
                LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_NOT_TOUCH_MODAL or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Обычное окно поверх приложений: Android 12+ пропускает касания, только если alpha < 0.8.
        // Окно службы спецвозможностей считается доверенным, там ограничения нет.
        lp.alpha = if (type == LayoutParams.TYPE_APPLICATION_OVERLAY) 0.7f else 1f
        lp.title = "CrtOverlay"
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        v.isClickable = false
        v.isFocusable = false
        wm.addView(v, lp)
        view = v
        paused = false
        CrtSettings.sp(ctx).registerOnSharedPreferenceChangeListener(prefListener)
        applySettings()
    }

    fun hide() {
        handler.removeCallbacks(ticker)
        CrtSettings.sp(ctx).unregisterOnSharedPreferenceChangeListener(prefListener)
        view?.let {
            try {
                it.onPause()
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
    }

    fun setPaused(p: Boolean) {
        paused = p
        view?.visibility = if (p) View.INVISIBLE else View.VISIBLE
        updateTicker()
    }

    fun applySettings() {
        val v = view ?: return
        val s = CrtSettings.load(ctx)
        v.crtRenderer.settings = s
        v.requestRender()
        updateTicker(s)
    }

    private fun updateTicker(s: CrtSettings = CrtSettings.load(ctx)) {
        handler.removeCallbacks(ticker)
        val animated = s.noise > 0.001f || s.flicker > 0.001f || s.roll > 0.001f
        if (!paused && view != null && animated) handler.post(ticker)
    }
}
