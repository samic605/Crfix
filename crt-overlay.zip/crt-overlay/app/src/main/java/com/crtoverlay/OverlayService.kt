package com.crtoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams

class OverlayService : Service() {

    companion object {
        const val ACTION_TOGGLE = "com.crtoverlay.TOGGLE"
        const val ACTION_STOP = "com.crtoverlay.STOP"
        private const val CHANNEL = "crt_overlay"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var view: CrtGlView? = null
    private var paused = false
    private val handler = Handler(Looper.getMainLooper())

    // ~30 кадров/с, только если включены анимированные эффекты
    private val ticker = object : Runnable {
        override fun run() {
            view?.requestRender()
            handler.postDelayed(this, 33)
        }
    }

    // ссылка должна храниться сильной — SharedPreferences держит слушатель слабо
    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applySettings() }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        addOverlay()
        CrtSettings.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> {
                paused = !paused
                applyPause()
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        CrtSettings.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        view?.let {
            try {
                it.onPause()
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
        running = false
        super.onDestroy()
    }

    private fun addOverlay() {
        val v = CrtGlView(this)
        val lp = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or
                LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_NOT_TOUCH_MODAL or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        // Android 12+: касания проходят сквозь оверлей, только если alpha окна строго меньше 0.8
        lp.alpha = 0.75f
        lp.title = "CrtOverlay"
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        view = v
        applySettings()
    }

    private fun applySettings() {
        val v = view ?: return
        val s = CrtSettings.load(this)
        v.crtRenderer.settings = s
        v.requestRender()
        updateTicker(s)
    }

    private fun updateTicker(s: CrtSettings = CrtSettings.load(this)) {
        handler.removeCallbacks(ticker)
        val animated = s.noise > 0.001f || s.flicker > 0.001f || s.roll > 0.001f
        if (!paused && animated) handler.post(ticker)
    }

    private fun applyPause() {
        view?.visibility = if (paused) View.INVISIBLE else View.VISIBLE
        updateTicker()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL, "CRT-фильтр", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        fun action(title: String, act: String, code: Int): Notification.Action {
            val pi = PendingIntent.getService(
                this, code,
                Intent(this, OverlayService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat_crt), title, pi
            ).build()
        }

        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_crt)
            .setContentTitle(if (paused) "CRT-фильтр на паузе" else "CRT-фильтр включён")
            .setContentText("Нажмите, чтобы изменить настройки")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action(if (paused) "Включить" else "Пауза", ACTION_TOGGLE, 1))
            .addAction(action("Выйти", ACTION_STOP, 2))
            .build()
    }
}
