package com.crtoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager.LayoutParams

/** Обычный режим: окно TYPE_APPLICATION_OVERLAY (нужно разрешение «Поверх других приложений»). */
class OverlayService : Service() {

    companion object {
        const val ACTION_TOGGLE = "com.crtoverlay.TOGGLE"
        const val ACTION_STOP = "com.crtoverlay.STOP"
        private const val CHANNEL = "crt_overlay"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }

    private lateinit var controller: OverlayController
    private var paused = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        controller = OverlayController(this, LayoutParams.TYPE_APPLICATION_OVERLAY)
        controller.show()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> if (::controller.isInitialized) {
                paused = !paused
                controller.setPaused(paused)
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        if (::controller.isInitialized) controller.hide()
        running = false
        super.onDestroy()
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL, "CRT-фильтр", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        fun action(title: String, act: String, code: Int): Notification.Action {
            val pi = PendingIntent.getService(
                this, code,
                Intent(this, OverlayService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_stat_crt), title, pi
            ).build()
        }

        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_crt)
            .setContentTitle(if (paused) "CRT-фильтр на паузе" else "CRT-фильтр включён")
            .setContentText("Нажмите, чтобы изменить настройки")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action(if (paused) "Включить" else "Пауза", ACTION_TOGGLE, 1))
            .addAction(action("Выйти", ACTION_STOP, 2))
            .build()
    }
}
