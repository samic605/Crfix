package com.crtoverlay

import java.io.File

class PassCfg(
    val file: File,
    val source: String,
    val filterLinear: Boolean,
    val wrap: String,
    val alias: String,
    val typeX: String,
    val typeY: String,
    val scaleX: Float,
    val scaleY: Float,
    val frameMod: Int
)

class LutCfg(val name: String, val file: File, val linear: Boolean, val wrap: String)

class ParamDef(
    val name: String,
    val desc: String,
    val def: Float,
    val min: Float,
    val max: Float,
    val step: Float
)

class RetroPreset(
    val passes: List<PassCfg>,
    val luts: List<LutCfg>,
    val overrides: Map<String, Float>
) {
    /** Параметры из строк `#pragma parameter` всех проходов. */
    val params: List<ParamDef> by lazy {
        val seen = LinkedHashMap<String, ParamDef>()
        for (p in passes) {
            for (line in p.source.lineSequence()) {
                val m = PRAGMA.matchEntire(line.trim()) ?: continue
                val g = m.groupValues
                val def = g[3].toFloatOrNull() ?: continue
                val min = g[4].toFloatOrNull() ?: continue
                val max = g[5].toFloatOrNull() ?: continue
                val step = g[6].toFloatOrNull() ?: 0f
                if (!seen.containsKey(g[1])) seen[g[1]] = ParamDef(g[1], g[2], def, min, max, step)
            }
        }
        seen.values.toList()
    }

    companion object {
        private val PRAGMA =
            Regex("""#pragma\s+parameter\s+(\w+)\s+"([^"]*)"\s+(\S+)\s+(\S+)\s+(\S+)(?:\s+(\S+))?.*""")
    }
}

object PresetParser {

    private class V(val value: String, val dir: File)

    private val INCLUDE = Regex("""\s*#include\s+["<]([^">]+)[">].*""")

    fun readSource(file: File, depth: Int = 0): String {
        val sb = StringBuilder()
        for (line in file.readLines()) {
            val m = INCLUDE.matchEntire(line)
            if (m != null && depth < 8) {
                val inc = File(file.parentFile, m.groupValues[1].replace('\\', '/')).canonicalFile
                if (inc.exists()) {
                    sb.append(readSource(inc, depth + 1)).append('\n')
                    continue
                }
            }
            sb.append(line).append('\n')
        }
        return sb.toString()
    }

    fun parse(file: File): RetroPreset {
        if (file.name.endsWith(".glsl", ignoreCase = true)) {
            val pass = PassCfg(file, readSource(file), true, "clamp_to_edge", "", "", "", 1f, 1f, 0)
            return RetroPreset(listOf(pass), emptyList(), emptyMap())
        }

        val kv = LinkedHashMap<String, V>()
        readKv(file, kv, 0)

        fun s(k: String): String? = kv[k]?.value
        fun b(k: String, d: Boolean): Boolean =
            s(k)?.let { it.equals("true", true) || it == "1" } ?: d
        fun f(k: String): Float? = s(k)?.toFloatOrNull()

        val n = s("shaders")?.trim()?.toIntOrNull()
            ?: throw IllegalArgumentException("В пресете нет параметра shaders (поддерживаются только .glslp)")
        if (n < 1) throw IllegalArgumentException("В пресете нет проходов")

        val passes = ArrayList<PassCfg>()
        for (i in 0 until n) {
            val e = kv["shader$i"] ?: throw IllegalArgumentException("Нет shader$i в пресете")
            val sf = File(e.dir, e.value.replace('\\', '/')).canonicalFile
            if (!sf.exists()) {
                throw IllegalArgumentException(
                    "Не найден файл шейдера: ${e.value}\nИмпортируйте всю папку glsl-shaders целиком, а не отдельный пресет."
                )
            }
            val tx = s("scale_type_x$i") ?: s("scale_type$i") ?: ""
            val ty = s("scale_type_y$i") ?: s("scale_type$i") ?: ""
            passes.add(
                PassCfg(
                    file = sf,
                    source = readSource(sf),
                    filterLinear = b("filter_linear$i", true),
                    wrap = s("wrap_mode$i") ?: "clamp_to_edge",
                    alias = s("alias$i") ?: "",
                    typeX = tx,
                    typeY = ty,
                    scaleX = f("scale_x$i") ?: f("scale$i") ?: 1f,
                    scaleY = f("scale_y$i") ?: f("scale$i") ?: 1f,
                    frameMod = s("frame_count_mod$i")?.toIntOrNull() ?: 0
                )
            )
        }

        val luts = ArrayList<LutCfg>()
        s("textures")?.split(';')?.map { it.trim() }?.filter { it.isNotEmpty() }?.forEach { name ->
            val e = kv[name] ?: return@forEach
            val tf = File(e.dir, e.value.replace('\\', '/')).canonicalFile
            if (tf.exists()) {
                luts.add(LutCfg(name, tf, b("${name}_linear", true), s("${name}_wrap_mode") ?: "clamp_to_edge"))
            }
        }

        val over = HashMap<String, Float>()
        s("parameters")?.split(';')?.map { it.trim() }?.filter { it.isNotEmpty() }?.forEach { name ->
            f(name)?.let { over[name] = it }
        }

        return RetroPreset(passes, luts, over)
    }

    private fun readKv(file: File, out: MutableMap<String, V>, depth: Int) {
        if (depth > 8) return
        for (raw in file.readLines()) {
            val line = raw.trim()
            if (line.startsWith("#reference")) {
                val p = line.removePrefix("#reference").trim().trim('"').replace('\\', '/')
                val ref = File(file.parentFile, p).canonicalFile
                if (ref.exists()) readKv(ref, out, depth + 1)
                continue
            }
            if (line.isEmpty() || line.startsWith("#")) continue
            val eq = line.indexOf('=')
            if (eq < 0) continue
            val key = line.substring(0, eq).trim()
            var v = line.substring(eq + 1).trim()
            v = if (v.startsWith("\"")) v.substring(1).substringBefore('"') else v.substringBefore('#').trim()
            out[key] = V(v, file.parentFile ?: file)
        }
    }
}
