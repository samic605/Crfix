package com.crtoverlay

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.File
import java.util.zip.ZipInputStream

/** Хранилище импортированных шейдеров RetroArch: filesDir/shaders. */
object ShaderLib {

    private val ALLOWED = setOf("glslp", "glsl", "glsli", "inc", "h", "png", "jpg", "jpeg", "bmp")

    fun root(ctx: Context): File = File(ctx.filesDir, "shaders").apply { mkdirs() }

    private fun ext(name: String) = name.substringAfterLast('.', "").lowercase()

    private fun safeName(s: String): String =
        s.replace(Regex("[^A-Za-z0-9._\\- ]"), "_").trim().ifEmpty { "imported" }

    /** Относительные пути пресетов (.glslp), CRT-пресеты — сверху. */
    fun listPresets(ctx: Context): List<String> {
        val root = root(ctx)
        val out = ArrayList<String>()
        root.walkTopDown().filter { it.isFile }.forEach { f ->
            val rel = f.relativeTo(root).path
            val e = ext(f.name)
            if (e == "glslp" || (e == "glsl" && rel.startsWith("_files" + File.separator))) out.add(rel)
        }
        return out.sortedWith(
            compareBy<String>({ if (it.lowercase().contains("crt")) 0 else 1 }, { it.lowercase() })
        )
    }

    fun clear(ctx: Context) {
        root(ctx).deleteRecursively()
        root(ctx)
    }

    /** Импорт папки (рекурсивно) через системный выбор папки. Возвращает число файлов. */
    fun importTree(ctx: Context, tree: Uri): Int {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val name = safeName(docId.substringAfterLast(':').substringAfterLast('/'))
        return copyDir(ctx, tree, docId, File(root(ctx), name))
    }

    private fun copyDir(ctx: Context, tree: Uri, docId: String, dest: File): Int {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val items = ArrayList<Triple<String, String, String>>()
        ctx.contentResolver.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) items.add(Triple(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: ""))
        }
        var n = 0
        for ((id, rawName, mime) in items) {
            val name = safeName(rawName)
            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                if (name.startsWith(".")) continue
                n += copyDir(ctx, tree, id, File(dest, name))
            } else if (ext(rawName) in ALLOWED) {
                dest.mkdirs()
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    File(dest, name).outputStream().use { input.copyTo(it) }
                    n++
                }
            }
        }
        return n
    }

    /** Импорт набора файлов: .zip распаковывается, остальные копируются в _files. */
    fun importFiles(ctx: Context, uris: List<Uri>): Int {
        var n = 0
        for (u in uris) {
            val name = displayName(ctx, u)
            n += if (ext(name) == "zip") importZip(ctx, u, name) else importOne(ctx, u, name)
        }
        return n
    }

    private fun displayName(ctx: Context, u: Uri): String {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "file"
        }
        return u.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    private fun importOne(ctx: Context, u: Uri, name: String): Int {
        if (ext(name) !in ALLOWED) return 0
        val dir = File(root(ctx), "_files").apply { mkdirs() }
        ctx.contentResolver.openInputStream(u)?.use { input ->
            File(dir, safeName(name)).outputStream().use { input.copyTo(it) }
            return 1
        }
        return 0
    }

    private fun importZip(ctx: Context, u: Uri, name: String): Int {
        val dest = File(root(ctx), safeName(name.substringBeforeLast('.')))
        dest.mkdirs()
        val base = dest.canonicalPath + File.separator
        var n = 0
        ctx.contentResolver.openInputStream(u)?.use { raw ->
            ZipInputStream(raw.buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (!e.isDirectory && ext(e.name) in ALLOWED) {
                        val out = File(dest, e.name).canonicalFile
                        if (out.path.startsWith(base)) {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { z.copyTo(it) }
                            n++
                        }
                    }
                    e = z.nextEntry
                }
            }
        }
        return n
    }
}
